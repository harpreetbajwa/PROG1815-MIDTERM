﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Harpreet_ITD_18011
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public int largestNumber(int a, int b)
        {
            if(a>b)
            {
                return a;
            }
            else 
            {
                return b;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try {
                int num1 = int.Parse(textBox1.Text);
                int num2 = int.Parse(textBox2.Text);
                int res = largestNumber(num1, num2);
                label3.Text = "Largest value is " + res.ToString();

                }
            catch(FormatException ex)
            {
                label3.Text = ex.Message;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] myarray = new string[4];
            myarray[0] = "C#";
            myarray[1] = "is an";
            myarray[2] = "interesting";
            myarray[3] = "language";
            array_label.Text = "";
            for(int i = 0; i<myarray.Length; i++)
            {
                array_label.Text += myarray[i] + " ";
            }

            comboBox1.Items.Add("Fall");
            comboBox1.Items.Add("Winter");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try {
                double x = 49;
                double y = 7;
                double result = x / y;
                labelForError.Text = result.ToString();
            }
            catch(FormatException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(NullReferenceException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(DivideByZeroException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void iTIDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 obj = new Form2();
            obj.MdiParent = this.ParentForm;
            obj.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if(comboBox1.SelectedIndex ==0)
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("PROG-1781");
                comboBox2.Items.Add("INFO-1265");
                comboBox2.Items.Add("INFO-1245");
            }
            else if(comboBox1.SelectedIndex ==1)
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("PROG-1815");
                comboBox2.Items.Add("PROG-1800");
                comboBox2.Items.Add("PROG-1825");
            }
            
        }
    }
}
